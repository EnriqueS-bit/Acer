#Parte 1-1
numero=int(input("Ingrese un numero: "))
if numero%2==0:
    print("El numero es par")
else:
    print("El numeroes impar")
